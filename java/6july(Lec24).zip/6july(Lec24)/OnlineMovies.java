class Netflix{
	static int Watchlist = 20;
	int Watched = 5;
	void moviesWatched(){
		System.out.println("NETFLIX of movies watched during quarantine : "+Watched);
	}
	static void displayWatchlist(){
		System.out.println("NETFLIX movies yet to watch during quarantine : "+Watchlist);
	}
}
class Prime{
	static int Watchlist = 15;
	int Watched = 10;
	void moviesWatched(){
		System.out.println("PRIME movies watched during quarantine : "+Watched);
	}
	static void displayWatchlist(){
		System.out.println("PRIME of movies yet to watch during quarantine : "+Watchlist);
	}
}

class SharedAccount{

	public static void main(String[] args){

		Netflix Atharv = new Netflix();
		Atharv.Watched = 4;
		Atharv.moviesWatched();
		Atharv.displayWatchlist();

		Netflix Kajal = new Netflix();
		Kajal.Watched = 3;
		Kajal.moviesWatched();
		Kajal.displayWatchlist();
	       
		Prime Viren = new Prime();
		Viren.Watched = 2;
		Viren.moviesWatched();
		Viren.displayWatchlist();

		Prime Sushma = new Prime();
		Sushma.Watched = 1;
		Sushma.moviesWatched();
		Sushma.displayWatchlist();

}
}
