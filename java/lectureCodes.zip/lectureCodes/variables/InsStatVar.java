class Kutumb{
	int mob=1;
	int laptop=1;
	static int tv=1;

void AshuMethod(){

System.out.println("mob="+mob);
System.out.println("laptop="+laptop);
System.out.println("tv="+tv);

}

void KajalMethod(){

System.out.println("mob="+mob);
System.out.println("laptop="+laptop);
System.out.println("tv="+tv);

}

public static void main(String[] args){

Kutumb obj1 = new Kutumb();
obj1.mob=0;
obj1.tv=0;
obj1.AshuMethod();


Kutumb obj2 = new Kutumb();
obj2.KajalMethod();




}



}
