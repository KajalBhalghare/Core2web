class BCCI{

static int a=10;
void Decision(){

System.out.println("Decision");

}

public static void main(String[] args){
	System.out.println(a);
       	IPL obj = new IPL();
	obj.EmergingPlayer();
}

}
class IPL{

void EmergingPlayer(){

	System.out.println("young cricketers");
	System.out.println(BCCI.a);



}





}
