class first{
	int mob=1;
	static int tv=1;

void Display(){

System.out.println("mob="+mob);
System.out.println("tv="+tv);

}

static void StatDisplay(){
first obj1 = new first();
System.out.println("mob="+obj1.mob);
System.out.println("tv="+tv);

}


}


class second{

public static void main(String[] args){
	first obj2 = new first();
	obj2.Display();
	first.StatDisplay();

}


}
