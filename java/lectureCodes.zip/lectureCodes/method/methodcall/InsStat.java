class Kutumb {

int mob=1;
int laptop=1;
int tv=1;

void display(){
	System.out.println("In display");
	}

static void StatDisplay(){
	System.out.println("In StatDisplay");
	}

public static void main(String[] args){

Kutumb obj= new Kutumb();
obj.display();
Kutumb.StatDisplay();
StatDisplay();


}




}
