class ByteDemo{
public static void main(String[] args){
	byte x = 127;
	x++;
	System.out.println(x);

	x++;
	System.out.println(x);

	x++;
	System.out.println(x);

}
}
