class floatDouble{
	public static void main(String[] args){

		float f=25.6f;
		double d=25.6;

		if(f==d)
			System.out.println("Same value");
		else
			System.out.println("Different value");
	
	
	
	
	
	}
}
