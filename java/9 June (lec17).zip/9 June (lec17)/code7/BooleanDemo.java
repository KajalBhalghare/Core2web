class BooleanDemo{
	public static void main(String[] args){	

		boolean x =true;
		System.out.println(x);
	
	}

}
