class intDemo{
	public static void main(String[] args){

		int x = 2147483647;

		x++;
		System.out.println(x);
	
	
		x++;
		System.out.println(x);
	
	
		x++;
		System.out.println(x);
	

	
	}

}
