class longDemo{
	public static void main(Sring[] args){

	long x = 9223372036854775807;	

	x++;
	System.out.println(x);
	
	
	x++;
	System.out.println(x);
	
	
	x++;
	System.out.println(x);
	
	
	}
}
