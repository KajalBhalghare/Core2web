class charDemo{

	public static void main(String[] args){	
		
		char ch = 65;
	        System.out.println(ch);	
	
	
	}

}
