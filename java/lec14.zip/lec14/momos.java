class Momos {
	int chutney=6;
	int mayonese=3;
	static int momos=3;

	void MyMomos(){
	 System.out.println("steam momos");	
	
	 System.out.println("chutney quantity="+chutney);
	 System.out.println("momos quantity="+momos);
		}

	
	static void FriendMomos(){
		System.out.println("fried momos");

		Momos mayo= new Momos();
		System.out.println("mayonese quantity"+mayo.mayonese);
		System.out.println("momos quantity"+momos);
	
	}

}

class order {

	public static void main(String[] args){
	
	Momos order1= new Momos();
	order1.MyMomos();

	Momos.FriendMomos();
	
	}

}







