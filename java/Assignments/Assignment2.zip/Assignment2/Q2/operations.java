class Calculations{
	int a =456;
	int b=123;
	int ans = 0;
	void Add(){
		ans=a+b;
		System.out.println("Add: "+ans);
	}
	
	void Subtract(){
		ans=a-b;
	System.out.println("Sub: "+ans);
	}
	
	void Multiply(){
		ans=a*b;
		System.out.println("Mul: "+ans);
	}
	
	void Divide(){
		ans=a/b;
		System.out.println("Div: "+ans);
	}
	
	void Modulus(){
		ans=a%b;
		System.out.println("Mod: "+ans);
	}
	
	public static void main(String[] args){

		Calculations obj1 = new Calculations();
		obj1.Add();
		obj1.Subtract();
		obj1.Multiply();
		obj1.Divide();
		obj1.Modulus();
	}

}
