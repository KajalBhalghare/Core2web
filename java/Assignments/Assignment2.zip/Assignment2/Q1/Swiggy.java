import java.lang.*;
class Dominos{
	int price = 300;
	int quantity = 2;
	
	static int total = 600;


	static void bill(){
		Dominos pizza = new Dominos();
		pizza.price=300;
		pizza.quantity=5;
		pizza.total= pizza.price*pizza.quantity;
		System.out.println("Pizza Price :"+pizza.price);
		System.out.println("Pizza quantity :"+pizza.quantity);
		System.out.println("total pizza cost:"+total);

		Dominos fries = new Dominos();
		fries.price=150;
		fries.quantity=3;
		fries.total= fries.price*fries.quantity;
		System.out.println("Fries Price :"+fries.price);
		System.out.println("Fries quantity :"+fries.quantity);
		System.out.println("total fries cost:"+total);

		
		System.out.println("Total meal cost: "+(pizza.price*pizza.quantity+fries.price*fries.quantity));
		//System.out.println("Total meal cost"+parseInt(pizza.price*pizza.quantity)+parseInt(fries.price*fries.quantity));
		
		
	}

	public static void main(String[] args){
		bill();

	}
}
