class Army{
	static int active = 1237117;     //Active personels cannot quit Army at will 
		int reserve = 960000;     //Reserve personels can

	static void FullTime(){
		System.out.println("Total active soldiers in Army:"+active);
		}
	void PartTime(){
		System.out.println("Total reserve soldiers in Army:"+reserve);
	}
}

class Navy{
	static int active = 67228; 
		int reserve = 55000;

	static void FullTime(){
		System.out.println("Total active soldiers in Navy:"+active);
		}
	void PartTime(){
		System.out.println("Total reserve soldiers in Navy"+reserve);
	}
}
class Airforce{
	static int active = 139576;
		int reserve = 140000;

	static void FullTime(){
		System.out.println("Total active soldiers in Airforce:"+active);
		}
	void PartTime(){
		System.out.println("Total reserve soldiers in Airforce:"+reserve);
	}
}
class Defence{
	public static void main(String[] args){
	
		Army mission1 = new Army();	
		mission1.reserve = 960001; 
		mission1.active = 1237349;
		mission1.FullTime();
		mission1.PartTime();
	

		Army mission2 = new Army();	
		mission2.FullTime();
		mission2.PartTime();
		
		Navy mission3 = new Navy();	
		mission3.FullTime();
		mission3.PartTime();
	
		Airforce mission4 = new Airforce();	
		mission4.FullTime();
		mission4.PartTime();
	
		
	
	}
}
