class BoycottChina{
	static int TotalChineseApps = 11823;
	int IndiaBans = 59;

	static void WorldWide_ChineseApps(){
	
	System.out.println("Total Chinese apps worldwide:"+TotalChineseApps);
	
	}

	void IndianGovt_BanApps(){
	
	
	System.out.println("Total chinese apps banned by Indian Government:"+IndiaBans);
	
	
	}


	public static void main(String[] args){
	
		BoycottChina playstore = new BoycottChina();
		playstore.IndianGovt_BanApps();
		WorldWide_ChineseApps();
	
	
	}
		
	

}
